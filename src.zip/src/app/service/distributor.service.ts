import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Retailer } from '../model/retailer.model';

@Injectable({
  providedIn: 'root'
})
export class DistributorService {
  private apiUrl='http://localhost:8088/api'
  private httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
 
  constructor(private http: HttpClient) {}
 
  // Get retailers associated with a specific distributor
  getRetailers(distributorId: number): Observable<Retailer[]> {
    const url = `${this.apiUrl}/distributor/${distributorId}/retailers`;
    return this.http.get<Retailer[]>(url);
  }
 
  // Add a new retailer
  addRetailer(retailer: Retailer): Observable<Retailer> {
    const url = `${this.apiUrl}/distributor/${retailer.distributorId}/retailers`;
    return this.http.post<Retailer>(url, retailer, this.httpOptions);
  }
}