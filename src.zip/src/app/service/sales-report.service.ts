import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class SalesReportService {
  private apiUrl = 'http://localhost:8088/api/sales';
 
  constructor(private http: HttpClient) {}
 
  getSalesReport(distributorId: number, startDate: string, endDate: string): Observable<any[]> {
    const url = `${this.apiUrl}/report`;
    return this.http.get<any[]>(url, {
      params: {
        startDate: startDate,
        endDate: endDate
      }
    });
  }
}