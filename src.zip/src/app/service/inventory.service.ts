import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Inventory } from '../model/inventory.model';
import { AuthService } from '../auth.service';
 
@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private apiUrl = 'http://localhost:8088/api/inventory'; // Update with your backend URL
 
  constructor(private http: HttpClient, private authService: AuthService) { }
 
  // Add new inventory
  addInventory(inventory: Inventory): Observable<Inventory> {
    const distributorId = this.authService.getLoggedInDistributorId(); // Fetch distributor ID
    const url = `${this.apiUrl}`;
    return this.http.post<Inventory>(url, inventory);
  }
 
  // Get inventory list for the current distributor
  getInventoryByDistributor(): Observable<any[]> {
    const distributorId = this.authService.getLoggedInDistributorId(); // Fetch distributor ID
    return this.http.get<any[]>(`${this.apiUrl}`);
  }
 
  private httpOptions() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
  }
}