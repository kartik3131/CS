import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from '../auth.service';
 
@Injectable({
  providedIn: 'root'
})
export class RetailerService {
  private apiUrl = 'http://localhost:8088/api/retailers'; // Update with your API URL
 
  constructor(private http: HttpClient, private authService: AuthService) {}
 
  getRetailers(): Observable<any[]> {
    const distributorId=this.authService.getLoggedInDistributorId();
    return this.http.get<any[]>(this.apiUrl);
  }
 
  addRetailer(retailer: any): Observable<any> {
return this.http.post<any>(this.apiUrl, retailer);
  }
 
  // Add methods for editing and deleting retailers if required
}