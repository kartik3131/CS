import { Component } from '@angular/core';
import { ReportService } from '../report.service';
import { OrderHistory } from '../OrderHistory';

@Component({
  selector: 'app-retailer-report',
  templateUrl: './retailer-report.component.html',
  styleUrl: './retailer-report.component.css'
})
export class RetailerReportComponent {
  orderHistory: OrderHistory[] = [];
  errorMessage: string = '';
 
  constructor(private reportService: ReportService) { }
 
  ngOnInit(): void {
    this.fetchOrderHistory();
  }

  
 
  fetchOrderHistory(): void {
    this.reportService.getOrderHistory().subscribe(
      (data:  OrderHistory[]) => {
        console.log(data)
        this.orderHistory = data;
        this.errorMessage='';
      },
      (error) => {
        this.errorMessage = 'Error fetching order history!';
        console.error(error);
      }
    );
  }
 
  cancelOrder(orderId: number): void {
    this.reportService.cancelOrder(orderId).subscribe(
      (response: any) => {
        console.log('Response from backend',response);
        alert('Order canceled successfully!');
        this.errorMessage='';
        this.fetchOrderHistory(); // Refresh order history after cancellation
      },
      (error) => {
        this.errorMessage = 'Error canceling the order!';
        console.error(error);
      }
    );
  }

}
