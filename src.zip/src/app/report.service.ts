import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ReportService {
  private apiUrl = 'http://localhost:8088/api/orders';

  constructor(private http: HttpClient) { }


  private getAuthHeaders():HttpHeaders{
    const token=localStorage.getItem('authToken');
    return new HttpHeaders({
      'Content-Type':'application/json',
      'Authorization':'Bearer ${token}'
    });
  }
  // Fetch order history
  getOrderHistory(): Observable<any> {
    return this.http.get(`${this.apiUrl}/history`);
  }
  cancelOrder(orderId: number): Observable<any> {
    const headers=this.getAuthHeaders();
    return this.http.post(`${this.apiUrl}/cancel`, { orderId },{headers});
      }
}
