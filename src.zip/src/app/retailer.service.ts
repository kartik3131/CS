import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class RetailerService {
 
  private apiUrl = 'http://localhost:8088/api/Retailer'; // Replace with your backend API URL
 
  constructor(private http: HttpClient) { }
 
  getInventory(): Observable<any> {
    return this.http.get(`${this.apiUrl}/inventory`);
  }
 
  getOrders(): Observable<any> {
    return this.http.get(`${this.apiUrl}/orders`);
  }
 
  getQuickStats(): Observable<any> {
    return this.http.get(`${this.apiUrl}/quick-stats`);
  }
  getMyRetailerDetails(): Observable<any>{
    const headers=new HttpHeaders({
      'Authorization':'Bearer'+localStorage.getItem('authToken')
    });
    return this.http.get<any>('${this.apiUrl}/me',{headers});
  }
}