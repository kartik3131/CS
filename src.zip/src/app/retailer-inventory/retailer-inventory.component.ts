import { Component } from '@angular/core';
import { InventoryService } from '../inventory.service';
import { RetailerService } from '../retailer.service';

@Component({
  selector: 'app-retailer-inventory',
  templateUrl: './retailer-inventory.component.html',
  styleUrl: './retailer-inventory.component.css'
})
export class RetailerInventoryComponent {
  inventoryItems:any[]=[];
  constructor(private inventoryService:InventoryService,private retailerService:RetailerService){}
  ngOnInit(){
    this.loadInventory();
  }
  loadInventory():void{
    this.inventoryService.getInventory().subscribe(
      (items:any[])=>this.inventoryItems=items,
      error=>console.error('Error fetching inventory',error)
    );
  }
}
