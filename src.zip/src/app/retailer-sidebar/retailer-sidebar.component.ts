import { Component } from '@angular/core';

@Component({
  selector: 'app-retailer-sidebar',
  templateUrl: './retailer-sidebar.component.html',
  styleUrl: './retailer-sidebar.component.css'
})
export class RetailerSidebarComponent {

}
