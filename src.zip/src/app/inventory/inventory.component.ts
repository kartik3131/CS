import { Component, OnInit } from '@angular/core';
import { InventoryService } from '../inventory.service';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrl: './inventory.component.css'
})
export class InventoryComponent {
  inventoryItems=[];
  searchTerm: string='';
  selectedFilter: string='';
  categories=['SIM Cards','Recharge Coupons', 'E-Top Ups'];
  constructor(private inventoryService: InventoryService){}
}
