export interface Inventory{
    id?: number;
    distributor?: any;
    itemType: string;
    quantity: number;
}