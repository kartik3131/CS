export interface Retailer{
    id?: number;
    name: string;
    email: string;
    distributorId: number;
}