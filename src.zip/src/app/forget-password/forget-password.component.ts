import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { TempDataService } from '../service/temp-data.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrl: './forget-password.component.css'
})
export class ForgetPasswordComponent {
  username: string = '';
  securityKey: string = '';
  message: string = '';
 
  constructor(private router: Router, private authService: AuthService, private tempDataService: TempDataService) { }
 
  validateKey() {
    this.authService.validateSecurityKey(this.username, this.securityKey).subscribe(
      response => {
        this.tempDataService.setUsername(this.username);
        this.message = 'Security key is valid. You can now reset your password.';
        this.router.navigate(['/reset-password']);
        // Redirect to reset password page or show reset form
      },
      error => {
        this.message = 'Invalid security key';
      }
    );
  }
}