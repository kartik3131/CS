import { Component } from '@angular/core';
import {Router} from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-retailer-header',
  templateUrl: './retailer-header.component.html',
  styleUrl: './retailer-header.component.css'
})
export class RetailerHeaderComponent {
  constructor(private authService: AuthService, private router: Router) {}
 
  logout(): void {
    this.authService.logout().subscribe(
      () => {
        // Handle successful logout
        this.router.navigate(['/login']); // Redirect to the login page
      },
      error => {
        // Handle logout error
        console.error('Logout failed', error);
      }
    );
  }
}
