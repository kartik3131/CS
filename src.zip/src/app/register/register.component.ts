import { Component,OnInit } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit{
registerForm:FormGroup;
roles:string[]=['Retailer','Distributor'];
constructor(private fb: FormBuilder, private router: Router,private authService:AuthService) {
  this.registerForm = this.fb.group({
       username: ['', Validators.required],
       password: ['', Validators.required],
       confirmPassword: ['', Validators.required],
       email:['',[Validators.required,Validators.email]],
       securityKey:['', Validators.required],
       role: ['', Validators.required]
     });
   }
  ngOnInit(): void {}
 
  onRegister(): void {
    if (this.registerForm.valid){
      const { username, password, email, securityKey, role } = this.registerForm.value;
 
      // Call AuthService to register
      this.authService.register({ username, password, email, securityKey, role }).subscribe(
        response => {
          // Handle successful registration
          console.log('Registration successful', response);
          this.router.navigate(['/login']);
        },
        error => {
          // Handle registration error
          console.error('Registration failed', error);
        }
      );
    }
  }
}
