
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { User } from '../user.model';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:User=new User('' , '');
  loginForm: FormGroup;
  roles: string[] = ['Admin', 'Retailer', 'Distributor'];
  errorMessage: string='';
 
  constructor(private fb: FormBuilder, private router: Router, private authService:AuthService) {
 this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      role: ['', Validators.required]
    });
  }
 
  ngOnInit(): void {}
 
  onSubmit(): void {
    if (this.loginForm.invalid) {
      return;
    }
      const { username, password, role } = this.loginForm.value;
      const loginPayload={
        username:username,
        password:password,
        role:role,
      };
      this.authService.login(loginPayload).subscribe(
        response=>{
          console.log("Login successful:", response);
          localStorage.setItem('token', response.jwt);

          if (role === 'Admin') {
            this.router.navigate(['/admin-dashboard']);
          } else if (role === 'Retailer') {
            this.router.navigate(['/retailer-dashboard']);
          } else if (role === 'Distributor') {
            this.router.navigate(['/distributor-dashboard']);
          }
        },
        error=>{
          console.error('login failed',error);
          this.errorMessage='Invalid username or password. Please try again.'
          alert("Login failed. Please try again");
        }
      );
    }
  }