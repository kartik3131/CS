import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InventoryService } from '../service/inventory.service';
import { Inventory } from '../model/inventory.model';
 
@Component({
  selector: 'app-view-inventory',
  templateUrl: './view-inventory.component.html',
  styleUrl: './view-inventory.component.css'
})
export class ViewInventoryComponent {
  newInventory: any = { itemType: '', quantity: 0 };
  inventoryList: any[] = [];
 
  constructor(private inventoryService: InventoryService) { }
 
  ngOnInit(): void {
    this.loadInventory();
  }
 
  addInventory(): void {
    this.inventoryService.addInventory(this.newInventory).subscribe(() => {
      this.loadInventory(); // Reload inventory list after adding new item
      this.newInventory = { itemType: '', quantity: 0 }; // Clear form
    });
  }
 
  loadInventory(): void {
    this.inventoryService.getInventoryByDistributor().subscribe(inventory => {
      this.inventoryList = inventory;
    });
  }
}