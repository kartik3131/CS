import { Component } from '@angular/core';
import { SalesReportService } from '../service/sales-report.service';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-view-sales-report',
  templateUrl: './view-sales-report.component.html',
  styleUrl: './view-sales-report.component.css'
})
export class ViewSalesReportComponent {
  startDate: string = '';
  endDate: string = '';
  sales: any[] = [];
  reportFetched: boolean = false;
 
  constructor(private salesService: SalesReportService, private authService: AuthService) {}
 
  ngOnInit(): void {}
 
  fetchSalesReport(): void {
    const distributorId = this.authService.getLoggedInDistributorId(); // Fetch distributor ID from AuthService
 
    this.salesService.getSalesReport(distributorId, this.startDate, this.endDate)
      .subscribe({
        next: (data) => {
          this.sales = data;
          this.reportFetched = true;
        },
        error: (err) => {
          console.error('Error fetching sales report', err);
          this.sales = [];
          this.reportFetched = true;
        }
    });
  }
}