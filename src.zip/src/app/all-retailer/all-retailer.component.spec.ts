import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllRetailerComponent } from './all-retailer.component';

describe('AllRetailerComponent', () => {
  let component: AllRetailerComponent;
  let fixture: ComponentFixture<AllRetailerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AllRetailerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllRetailerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
