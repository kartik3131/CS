import { Component } from '@angular/core';

@Component({
  selector: 'app-all-retailer',
  templateUrl: './all-retailer.component.html',
  styleUrl: './all-retailer.component.css'
})
export class AllRetailerComponent {

}
