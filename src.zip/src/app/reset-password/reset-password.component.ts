import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { TempDataService } from '../service/temp-data.service';
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrl: './reset-password.component.css'
})
export class ResetPasswordComponent implements OnInit{
  resetPasswordForm!: FormGroup;
  username: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  message: string = '';
 
  constructor(private authService: AuthService, private formBuilder: FormBuilder, private router: Router, private tempDataService: TempDataService) { }

  ngOnInit(): void{
    this.username = this.tempDataService.getUsername();
    this.resetPasswordForm = this.formBuilder.group({newPassword: ['', [Validators.required,
      Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    });
  }
 
  resetPassword() {
    if (this.newPassword === this.confirmPassword) {
      this.authService.resetPassword(this.username, this.newPassword).subscribe(
        response => {
          this.message = 'Password reset successful. Redirecting to login page...';
          setTimeout(() => this.router.navigate(['/login']), 3000);
        },
        error => {
          this.message = 'Password reset failed';
        }
      );
    } else {
      this.message = 'Passwords do not match';
    }
  }
}