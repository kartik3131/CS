import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DistributorService } from '../service/distributor.service';
import { Retailer } from '../model/retailer.model';
import { RetailerService } from '../service/retailer.service';

@Component({
  selector: 'app-manage-retailers',
  templateUrl: './manage-retailer.component.html',
  styleUrls: ['./manage-retailer.component.css']
})
export class ManageRetailersComponent implements OnInit {
  retailers: any[]=[];
  constructor(private retailerService: RetailerService, private fb: FormBuilder) {}

  ngOnInit(): void{
    this.loadRetailers();
  }

  loadRetailers(): void {
    this.retailerService.getRetailers().subscribe(data => {
      this.retailers=data;
    },
    error => {
      console.error('Error fetching retailers: ', error);
    }
  );
  }
}
