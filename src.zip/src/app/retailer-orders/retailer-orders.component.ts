import { Component } from '@angular/core';
import { OrdersService } from '../orders.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-retailer-orders',
  templateUrl: './retailer-orders.component.html',
  styleUrl: './retailer-orders.component.css'
})
export class RetailerOrdersComponent {
  inventoryItems: any[] = [];  // List of inventory items fetched from the backend
  orderItems: any[] = [];      // Array to hold selected items and their quantities
  message: string = '';        // Message to display after placing an order
 
  constructor(private orderService: OrdersService, private router: Router) {}
 
  ngOnInit(): void {
    this.loadInventory();
  }
 
  // Fetch inventory items when the component loads
  loadInventory(): void {
    this.orderService.getInventoryForRetailer().subscribe(
      (data: any[]) => {
        this.inventoryItems = data;  // Update the component's inventoryItems with the data from the backend
      },
      (error) => {
        this.message = 'Error fetching inventory: ' + error.message;
      }
    );
  }
 
  // Add item to order
  addToOrder(inventoryItem: any, quantity: number): void {
    if (quantity > 0) {
      this.orderItems.push({ inventory: inventoryItem, quantity: quantity });
    }
  }
 
  // Place the order
  placeOrder(): void {
    if (this.orderItems.length === 0) {
      this.message = 'Please select items to order';
      return;
    }
 
    this.orderService.placeOrder(this.orderItems).subscribe(
      (response) => {
        console.log(response);
        this.message = response.message;
        console.log(response);  // Success or insufficient stock message
        alert("Order placed succesfully")
        if (response.message.includes('Order placed successfully')) {
          console.log(response);
          this.orderItems = [];  // Reset the order form
        }
      },
      (error) => {
        this.message = 'Error placing order: ' + error.message;
      }
    );
  }
}
