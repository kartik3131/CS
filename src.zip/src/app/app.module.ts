import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { RetailerDashboardComponent } from './retailer-dashboard/retailer-dashboard.component';
import { DistributorDashboardComponent } from './distributor-dashboard/distributor-dashboard.component';
import { RegisterComponent } from './register/register.component';
import { RetailerInventoryComponent } from './retailer-inventory/retailer-inventory.component';
import { RetailerOrdersComponent } from './retailer-orders/retailer-orders.component';
import { RetailerHeaderComponent } from './retailer-header/retailer-header.component';
import { RetailerSidebarComponent } from './retailer-sidebar/retailer-sidebar.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './auth.interceptor';
import { FilterPipe } from './filter.pipe';
import { CommonModule } from '@angular/common';
import { ManageRetailersComponent } from './manage-retailer/manage-retailer.component';
import { ViewSalesReportComponent } from './view-sales-report/view-sales-report.component';
import { ViewInventoryComponent } from './view-inventory/view-inventory.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatDialogModule } from '@angular/material/dialog';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { RetailerReportComponent } from './retailer-report/retailer-report.component';
import { AllRetailerComponent } from './all-retailer/all-retailer.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminDashboardComponent,
    RetailerDashboardComponent,
    DistributorDashboardComponent,
    RegisterComponent,
    RetailerInventoryComponent,
    RetailerOrdersComponent,
    RetailerHeaderComponent,
    RetailerSidebarComponent,
    FilterPipe,
    ManageRetailersComponent,
    ViewSalesReportComponent,
    ViewInventoryComponent,
    ForgetPasswordComponent,
    ResetPasswordComponent,
    RetailerReportComponent,
    AllRetailerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    CommonModule,
    MatFormFieldModule,
    MatDialogModule
  ],
  providers: [
    {provide: HTTP_INTERCEPTORS,useClass:AuthInterceptor,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
