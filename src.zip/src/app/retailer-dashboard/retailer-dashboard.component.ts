import { Component, OnInit } from '@angular/core';
import { RetailerService } from '../retailer.service';
 
@Component({
  selector: 'app-retailer-dashboard',
  templateUrl: './retailer-dashboard.component.html',
  styleUrls: ['./retailer-dashboard.component.css']
})
export class RetailerDashboardComponent implements OnInit {
 
  quickStats: any;
  recentOrders: any;
 
  constructor(private retailerService: RetailerService) { }
 
  ngOnInit(): void {
    this.loadQuickStats();
    this.loadRecentOrders();
  }
 
  loadQuickStats() {
    this.retailerService.getQuickStats().subscribe(data => {
      this.quickStats = data;
    });
  }
 
  loadRecentOrders() {
    this.retailerService.getOrders().subscribe(data => {
      this.recentOrders = data;
    });
  }
}
