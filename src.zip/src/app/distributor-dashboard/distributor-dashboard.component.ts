import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-distributor-dashboard',
  templateUrl: './distributor-dashboard.component.html',
  styleUrl: './distributor-dashboard.component.css'
})
export class DistributorDashboardComponent {
  constructor(private authService: AuthService, private router: Router) {}
 
  logout(): void {
    this.authService.logout().subscribe(
      () => {
        // Handle successful logout
        this.router.navigate(['/login']); // Redirect to the login page
      },
      error => {
        // Handle logout error
        console.error('Logout failed', error);
      }
    );
  }
}