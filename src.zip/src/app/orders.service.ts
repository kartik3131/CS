import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';

 
@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  private apiUrl = 'http://localhost:8088/api';  // Replace with actual backend URL
 
  constructor(private http: HttpClient) { }
 
  // Method to fetch inventory for the retailer
  getInventoryForRetailer(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/distributor/inventory`);  // Adjust the endpoint if needed
  }
 
  // Method to place an order (as shown earlier)
  placeOrder(orderItems: any[]): Observable<any> {
    const headers=new HttpHeaders({'Content-Type':'application/json'});
return this.http.post<any>(`${this.apiUrl}/orders/place`, orderItems,{headers,responseType:'text' as 'json'})
.pipe(
  catchError(error=>{
    console.error('Error placing order:',error);
    return throwError(error);
  })
  );
  } 
 
}