import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { map } from 'rxjs/operators';
import { User } from './user.model';
 
@Injectable({
  providedIn: 'root'
})
export class AuthService {
private apiUrl = 'http://localhost:8088/api/auth'; // Update with your API URL
  private authTokenKey = 'authToken'; // Key for localStorage
 
  constructor(private http: HttpClient) {}
  getLoggedInDistributorId(): number {
    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    return userDetails.distributorId;
  }
 
  // Register a new user
  register(user: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, user).pipe(
      catchError(this.handleError('register'))
    );
  }
 
  // Log in a user
  login(user: User): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login`, user,{
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  }) 
    }).pipe(
  map(response=>{
    if(response && response.token){
      this.storeToken(response.token);
      return response;
    }else{
      throw new Error('No token found in response');
    }
    
  }),
 catchError(error=>{
  console.error('login error',error);
  return throwError(()=>new Error(error.error || 'login failed'));
 })
    );
  }
 
  // Log out the user
  logout(): Observable<any> {
    return this.http.post(`${this.apiUrl}/logout`, {}, {headers:this.getAuthHeaders()}).pipe(
      tap(() => this.clearToken()),
      catchError(this.handleError('logout'))
    );
  }
 
  // Check if user is logged in
  isLoggedIn(): boolean {
    return !!this.getToken();
  }
 
  // Get the authentication token from local storage
  public getToken(): string | null {
    return localStorage.getItem(this.authTokenKey);
  }
 
  // Store token in local storage
  private storeToken(token: string): void {
    localStorage.setItem(this.authTokenKey, token);
  }
 
  // Clear token from local storage
  private clearToken(): void {
    localStorage.removeItem(this.authTokenKey);
  }
 
  // Get auth headers for protected routes
  private getAuthHeaders():  HttpHeaders  {
    const token = this.getToken();
     return new HttpHeaders().set('Authorization', `Bearer ${token}`);
    
  }
 
  // Error handling
  private handleError(operation = 'operation') {
    return (error: any): Observable<any> => {
      // Log error to console or send to a remote logging service
      console.error(`${operation} failed: ${error.message}`);
      // Notify user with a user-friendly message
      return of(error as any);
    };
  }
  validateSecurityKey(username: string, securityKey: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/validate`, {
          username,
          securityKey
        });
      }
     
      resetPassword(username: string, newPassword: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/reset-password`, {
          username,
          password: newPassword
        });
      }
}
