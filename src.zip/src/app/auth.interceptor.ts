import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from './auth.service';
 
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
 
  constructor(private authService: AuthService) {}
 
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
  
 
    // Add authorization header with JWT token if available
    const token = this.authService.getToken();
    if (token) {
      request = request.clone({
        setHeaders:{Authorization:`Bearer ${token}`,
        'Content-Type': 'application/json'}
        
      });
    }
 
    return next.handle(request).pipe(
      catchError((error:HttpErrorResponse )=> {
        // Handle errors globally here
        console.error('Http error occurred:', {
          status:error.status,
          statusText:error.statusText,
          url:error.url,
          message:error.message
        });
        return throwError(()=>new Error(error.message || 'server error'));
      })
    );
  }
}
