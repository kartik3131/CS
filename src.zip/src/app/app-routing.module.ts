import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { RetailerDashboardComponent } from './retailer-dashboard/retailer-dashboard.component';
import { DistributorDashboardComponent } from './distributor-dashboard/distributor-dashboard.component';
import { RegisterComponent } from './register/register.component';
import { RetailerInventoryComponent } from './retailer-inventory/retailer-inventory.component';
import { RetailerOrdersComponent } from './retailer-orders/retailer-orders.component';
import { ManageRetailersComponent } from './manage-retailer/manage-retailer.component';
import { ViewInventoryComponent } from './view-inventory/view-inventory.component';
import { ViewSalesReportComponent } from './view-sales-report/view-sales-report.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { RetailerReportComponent } from './retailer-report/retailer-report.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'admin-dashboard', component: AdminDashboardComponent },
  { path: 'retailer-dashboard', component: RetailerDashboardComponent },
  { path: 'distributor-dashboard', component: DistributorDashboardComponent },
  { path: 'register',component:RegisterComponent},
  { path: '', redirectTo: '/login', pathMatch: 'full' }, // Redirect to login by default
  { path: 'inventory',component:RetailerInventoryComponent},
  { path: 'orders',component:RetailerOrdersComponent},
  { path: 'manage-retailer', component: ManageRetailersComponent},
  { path: 'view-inventory', component: ViewInventoryComponent},
  { path: 'view-sales-report', component: ViewSalesReportComponent},
  { path: 'forget-password', component: ForgetPasswordComponent},
  { path: 'reset-password', component: ResetPasswordComponent},
  {path:'reports',component:RetailerReportComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
